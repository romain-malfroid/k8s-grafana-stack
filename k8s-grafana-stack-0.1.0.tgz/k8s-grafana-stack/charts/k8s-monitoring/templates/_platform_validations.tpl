{{ define "validations.platform" -}}
  {{- $platform := "" }}
  {{- if (.Capabilities.APIVersions.Has "security.openshift.io/v1/SecurityContextConstraints") }}
    {{- $platform = "openshift" }}
    {{- include "validations.platform.openshift" . }}
  {{- end }}

  {{- range $node := (lookup "v1" "Node" "" "").items }}
    {{- if eq $platform "" }}
      {{- range $label, $value := $node.metadata.labels }}
        {{- if regexMatch "kubernetes.azure.com.*" $label }}
          {{- $platform = "aks" }}
          {{- include "validations.platform.aks" $ }}
        {{- end }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}

{{ define "validations.platform.aks" -}}
  {{- range $collectorName := (include "collectors.list.enabled" .) | fromYamlArray }}
    {{- $collectorValues := (include "collector.alloy.values" (deepCopy $ | merge (dict "collectorName" $collectorName)) | fromYaml) }}
    {{- if ne (dig "controller" "podAnnotations" "kubernetes.azure.com/set-kube-service-host-fqdn" "false" $collectorValues) "true" }}
      {{- $msg := list "" "This Kubernetes cluster appears to be Azure AKS." }}
      {{- $msg = append $msg "To ensure connectivity to the API server, please set:" }}
      {{- $msg = append $msg (printf "%s:" $collectorName) }}
      {{- $msg = append $msg "  controller:" }}
      {{- $msg = append $msg "    podAnnotations:" }}
      {{- $msg = append $msg "      kubernetes.azure.com/set-kube-service-host-fqdn: \"true\"" }}
      {{- fail (join "\n" $msg) }}
    {{- end }}
  {{- end }}
  {{- if and ($.Values.clusterMetrics.enabled) ((index $.Values.clusterMetrics "kube-state-metrics").enabled) }}
    {{- if ne (dig "podAnnotations" "kubernetes.azure.com/set-kube-service-host-fqdn" "false" (index $.Values.clusterMetrics "kube-state-metrics")) "true" }}
      {{- $msg := list "" "This Kubernetes cluster appears to be Azure AKS." }}
      {{- $msg = append $msg "To ensure connectivity to the API server, please set:" }}
      {{- $msg = append $msg "clusterMetrics:" }}
      {{- $msg = append $msg "  kube-state-metrics:" }}
      {{- $msg = append $msg "    podAnnotations:" }}
      {{- $msg = append $msg "      kubernetes.azure.com/set-kube-service-host-fqdn: \"true\"" }}
      {{- fail (join "\n" $msg) }}
    {{- end }}
  {{- end }}
{{- end }}

{{ define "validations.platform.openshift" -}}
  {{- if not (eq .Values.global.platform "openshift") }}
    {{- $msg := list "" "This Kubernetes cluster appears to be OpenShift. Please set the platform to enable compatibility:" }}
    {{- $msg = append $msg "global:" }}
    {{- $msg = append $msg "  platform: openshift" }}
    {{- fail (join "\n" $msg) }}
  {{- end }}
{{- end }}
